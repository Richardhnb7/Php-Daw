<?php

namespace App\Entity;

use App\Repository\PedidosRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PedidosRepository::class)]
class Pedidos
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'date')]
    private $Fecha;

    #[ORM\Column(type: 'integer')]
    private $enviado;

    #[ORM\ManyToOne(targetEntity: Restaurante::class, inversedBy: 'pedidos')]
    private $Restaurante;

    #[ORM\OneToMany(mappedBy: 'Pedido', targetEntity: PedidosProductos::class)]
    private $pedidosProductos;

    public function __construct()
    {
        $this->pedidosProductos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFecha(): ?\DateTimeInterface
    {
        return $this->Fecha;
    }

    public function setFecha(\DateTimeInterface $Fecha): self
    {
        $this->Fecha = $Fecha;

        return $this;
    }

    public function getEnviado(): ?int
    {
        return $this->enviado;
    }

    public function setEnviado(int $enviado): self
    {
        $this->enviado = $enviado;

        return $this;
    }

    public function getRestaurante(): ?Restaurante
    {
        return $this->Restaurante;
    }

    public function setRestaurante(?Restaurante $Restaurante): self
    {
        $this->Restaurante = $Restaurante;

        return $this;
    }

    /**
     * @return Collection|PedidosProductos[]
     */
    public function getPedidosProductos(): Collection
    {
        return $this->pedidosProductos;
    }

    public function addPedidosProducto(PedidosProductos $pedidosProducto): self
    {
        if (!$this->pedidosProductos->contains($pedidosProducto)) {
            $this->pedidosProductos[] = $pedidosProducto;
            $pedidosProducto->setPedido($this);
        }

        return $this;
    }

    public function removePedidosProducto(PedidosProductos $pedidosProducto): self
    {
        if ($this->pedidosProductos->removeElement($pedidosProducto)) {
            // set the owning side to null (unless already changed)
            if ($pedidosProducto->getPedido() === $this) {
                $pedidosProducto->setPedido(null);
            }
        }

        return $this;
    }
}
