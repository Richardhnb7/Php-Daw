<?php

namespace App\Entity;

use App\Repository\PedidosProductosRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PedidosProductosRepository::class)]
class PedidosProductos
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'integer')]
    private $Unidades;

    #[ORM\ManyToOne(targetEntity: Pedidos::class, inversedBy: 'pedidosProductos')]
    private $Pedido;

    #[ORM\ManyToOne(targetEntity: Productos::class, inversedBy: 'pedidosProductos')]
    private $Producto;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUnidades(): ?int
    {
        return $this->Unidades;
    }

    public function setUnidades(int $Unidades): self
    {
        $this->Unidades = $Unidades;

        return $this;
    }

    public function getPedido(): ?Pedidos
    {
        return $this->Pedido;
    }

    public function setPedido(?Pedidos $Pedido): self
    {
        $this->Pedido = $Pedido;

        return $this;
    }

    public function getProducto(): ?Productos
    {
        return $this->Producto;
    }

    public function setProducto(?Productos $Producto): self
    {
        $this->Producto = $Producto;

        return $this;
    }
}
