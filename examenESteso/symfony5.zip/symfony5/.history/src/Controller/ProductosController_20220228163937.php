<?php

namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

class ProductosController extends AbstractController
{
    #[Route('/productos', name: 'productos')]
    public function index(): Response
    {
        return $this->render('productos/index.html.twig', [
            'controller_name' => 'ProductosController',
        ]);
    }
    #[Route('/productos_total', name: 'productos_total')]
    public function index2(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();
        $total_productos = $em->getRepository('App\Entity\Productos')->totalProductos();
        
        return $this->render('productos/total_productos.html.twig', [
            'total_productos' => $total_productos,
        ]);
    }
}
