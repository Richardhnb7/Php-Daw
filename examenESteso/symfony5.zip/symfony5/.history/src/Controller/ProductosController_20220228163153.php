<?php

namespace App\Controller;
use App\controller\ProductosController
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductosController extends AbstractController
{
    #[Route('/productos', name: 'productos')]
    public function index(): Response
    {
        return $this->render('productos/index.html.twig', [
            'controller_name' => 'ProductosController',
        ]);
    }
    #[Route('/productos_total', name: 'productos_total')]
    public function index(ManagerRegistry $em): Response
    {
        
        return $this->render('productos/index.html.twig', [
            'controller_name' => 'ProductosController',
        ]);
    }
}
