<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class Ejercicio1Controller extends AbstractController
{
    public function __construct(private ManagerRegistry $doctrine) {}
    #[Route('/ejercicio1', name: 'ejercicio1')]
    public function index(): Response
    {
        return $this->render('ejercicio1/index.html.twig', [
            'controller_name' => 'Ejercicio1Controller',
        ]);
    }
    #[Route('/consultasEjercicio1', name: 'consultas')]
    public function index4(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $id = 1;
        $total = $em->getRepository('App\Entity\Producto')->productoQueTieneCategoria($id);
        
        return $this->render('consultas/consultas.twig', [
            'total' => $total,
        ]);
    }
}
