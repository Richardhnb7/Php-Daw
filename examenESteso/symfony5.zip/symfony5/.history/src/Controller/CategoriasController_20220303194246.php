<?php

namespace App\Controller;
use App\Entity\Restaurante;
use App\Form\RestauranteType;
use App\Repository\RestauranteRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CategoriasController extends AbstractController
{
    public function __construct(private ManagerRegistry $doctrine) {}
    #[Route('/', name: 'App_listado_categorias')]
    public function listado(CategoriasRepository $CategoriasRepository)
    {
        $categorias=$CategoriasRepository->findAll();
        return $this->render('categorias/listado.html.twig', [
            'categorias' => $categorias,
        ]);

    }
    
    #[Route('/consultas', name: 'consultas')]
    public function index4(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $id = 1;
        $total = $em->getRepository('App\Entity\Producto')->productoQueTieneCategoria($id);
        
        return $this->render('consultas/find_byPedidos.twig', [
            'total' => $total,
        ]);
    }

}
