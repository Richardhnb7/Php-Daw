<?php

namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

class ConsultasController extends AbstractController
{
    public function __construct(private ManagerRegistry $doctrine) {}
    #[Route('/consultas_findAll', name: 'consultas')]
    public function index(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();
        
        return $this->render('consultas/findAll.twig', [
            'consulta' => $em->getRepository('App\Entity\Restaurante')->findAll(),
        ]);
    }

    #[Route('/consultas_findBy', name: 'consultas2')]
    public function index2(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $correo = "madrid1@empresa.com";
        $by_email = $em->getRepository('App\Entity\Restaurante')->findByEmail($correo);
        
        return $this->render('consultas/findBy.twig', [
            'by_email' => $by_email,
        ]);
    }

    #[Route('/consultas_findOneBy', name: 'consultas3')]
    public function index2(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $correo = "madrid1@empresa.com";
        $by_email = $em->getRepository('App\Entity\Restaurante')->findByEmail($correo);
        
        return $this->render('consultas/findBy.twig', [
            'by_email' => $by_email,
        ]);
    }
}