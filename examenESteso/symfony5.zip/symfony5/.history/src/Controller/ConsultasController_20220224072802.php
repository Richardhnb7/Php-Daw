<?php

namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

class ConsultasController extends AbstractController
{
    public function __construct(private ManagerRegistry $doctrine) {}
    #[Route('/consultas_find_all', name: 'consultas')]
    public function index(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();
        
        return $this->render('consultas/find_all.twig', [
            'consulta' => $em->getRepository('App\Entity\Restaurante')->findAll(),
        ]);
    }

    #[Route('/consultas_findBy', name: 'consultas2')]
    public function index2(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $clave = "1234";
        $by_clave = $em->getRepository('App\Entity\Restaurante')->findBy($clave);
        
        return $this->render('consultas/find_by.twig', [
            'by_clave' => $by_clave,
        ]);
    }

    #[Route('/consultas_find_one_by', name: 'consultas3')]
    public function index3(ManagerRegistry $em): Response
    {
        $em = $this->doctrine->getManager();

        $id = 1;
        $by_one_by_id = $em->getRepository('App\Entity\Restaurante')->findOneById($id);
        
        return $this->render('consultas/find_one_by.twig', [
            'by_one_by_id' => $by_one_by_id,
        ]);
    }
}