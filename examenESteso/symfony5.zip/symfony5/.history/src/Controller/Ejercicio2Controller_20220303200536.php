<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;


class Ejercicio2Controller extends AbstractController
{
    #[Route('/ejercicio2', name: 'ejercicio2')]
    public function index(): Response
    {
        return $this->render('ejercicio2/index.html.twig', [
            'controller_name' => 'Ejercicio2Controller',
        ]);
    }
}
