<?php

namespace App\Entity;

use App\Repository\ProductosRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProductosRepository::class)]
class Productos
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $Nombre;

    #[ORM\Column(type: 'string', length: 255)]
    private $Descripcion;

    #[ORM\Column(type: 'float')]
    private $Peso;

    #[ORM\Column(type: 'integer')]
    private $Stock;

    #[ORM\ManyToOne(targetEntity: Categorias::class)]
    private $Categoria;

    #[ORM\OneToMany(mappedBy: 'Producto', targetEntity: PedidosProductos::class)]
    private $pedidosProductos;

    public function __construct()
    {
        $this->pedidosProductos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->Nombre;
    }

    public function setNombre(string $Nombre): self
    {
        $this->Nombre = $Nombre;

        return $this;
    }

    public function getDescripcion(): ?string
    {
        return $this->Descripcion;
    }

    public function setDescripcion(string $Descripcion): self
    {
        $this->Descripcion = $Descripcion;

        return $this;
    }

    public function getPeso(): ?float
    {
        return $this->Peso;
    }

    public function setPeso(float $Peso): self
    {
        $this->Peso = $Peso;

        return $this;
    }

    public function getStock(): ?int
    {
        return $this->Stock;
    }

    public function setStock(int $Stock): self
    {
        $this->Stock = $Stock;

        return $this;
    }

    public function getCategoria(): ?Categorias
    {
        return $this->Categoria;
    }

    public function setCategoria(?Categorias $Categoria): self
    {
        $this->Categoria = $Categoria;

        return $this;
    }

    /**
     * @return Collection|PedidosProductos[]
     */
    public function getPedidosProductos(): Collection
    {
        return $this->pedidosProductos;
    }

    public function addPedidosProducto(PedidosProductos $pedidosProducto): self
    {
        if (!$this->pedidosProductos->contains($pedidosProducto)) {
            $this->pedidosProductos[] = $pedidosProducto;
            $pedidosProducto->setProducto($this);
        }

        return $this;
    }

    public function removePedidosProducto(PedidosProductos $pedidosProducto): self
    {
        if ($this->pedidosProductos->removeElement($pedidosProducto)) {
            // set the owning side to null (unless already changed)
            if ($pedidosProducto->getProducto() === $this) {
                $pedidosProducto->setProducto(null);
            }
        }

        return $this;
    }
    public function __toString() {
        return $this->id." ".$this->Nombre." ".$this->Descripcion." ".$this->Peso." ".$this->Stock." ".$this->Categoria;
    }
}
