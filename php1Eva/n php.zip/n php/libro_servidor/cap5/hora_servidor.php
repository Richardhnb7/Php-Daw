<?php
	echo date("h:m:s");