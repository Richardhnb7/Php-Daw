<!DOCTYPE html>
 <html>
   <head>
      <title>Número aleatorio</title>
   </head>
   <body>
   <?php
       echo rand(0, 100);
  ?>
  </body>
</html>
