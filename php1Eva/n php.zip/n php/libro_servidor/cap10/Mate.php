<?php
	class Mate{
    /**	
     * @param float $base
	 * @param float $exponente
     * @return float $resul
     */
    public function potencia($base, $exponente)
    {
        return pow($base, $exponente);
    }
}
