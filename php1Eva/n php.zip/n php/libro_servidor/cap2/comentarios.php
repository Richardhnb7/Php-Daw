<?php
	//comentario de línea
	$a = 0; // comentario de línea
	/* comentario 
	   de bloque
	*/
	# comentario de una sola línea