<?php	
	$var = "Paco";
	echo "Hola $var <br>";
	echo 'Hola $var <br>';
	echo "Hola " . $var;
	
