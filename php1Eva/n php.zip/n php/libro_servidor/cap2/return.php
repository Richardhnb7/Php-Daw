<?php
	$a = 0;
	if ($a == 0){
		return;
	}
	echo "Después del if";
