<?php
	$var = 3;
	switch ($var) {
		case 1:
			echo "Es un uno";
			break;
		case 2:
			echo "Es un dos";
			break;
		case 3:
			echo "Es un tres";
			break;
		default:
			echo "No es un uno, ni un dos, ni un tres";
	}