<!DOCTYPE html>
<html>
	<head>
		<title>Hola mundo</title>
	</head>
	<body>
	<?php
		echo "Hola mundo";
	?>
	</body>
</html>