<?php
	$a = "variable del principal";
	require "ejerequerido.php";
	$b = "otra variable del principal";
	echo "En el script principal";
