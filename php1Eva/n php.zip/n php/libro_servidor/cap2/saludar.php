<?php
	function saludar($nombre = 'usuario'){
		echo "Hola $nombre <br>";
	}
	saludar();
	saludar("Ana");
