<?php
	echo "Hola " . $_GET["nombre"];